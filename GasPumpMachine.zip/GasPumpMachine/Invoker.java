import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Invoker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Invoker{
  //public abstract void setCommand(Command cmd);
  public void press();
}