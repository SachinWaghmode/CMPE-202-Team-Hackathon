import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GasPumpWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public GasPumpWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 700, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        KeyPad keypad = new KeyPad();
        addObject(keypad,445,457);
        Screendisplay screen = new Screendisplay();
        addObject(screen,481,186);
        keypad.setLocation(479,407);
        keypad.setLocation(452,408);
        CardHolder cardholder = new CardHolder();
        addObject(cardholder,769,312);
        cardholder.setLocation(654,411);
        CreditCard creditcard = new CreditCard();
        addObject(creditcard,894,126);
        creditcard.setLocation(889,94);
        InvalidCard invalidcard = new InvalidCard();
        addObject(invalidcard,763,286);
        invalidcard.setLocation(889,252);
        invalidcard.setLocation(130,85);
        GasPumpMachine gaspumpmachine = new GasPumpMachine();
        addObject(gaspumpmachine,515,306);
        gaspumpmachine.setLocation(275,429);
        gaspumpmachine.setLocation(543,351);
        gaspumpmachine.setLocation(543,352);
        Nozzle nozzle = new Nozzle();
        addObject(nozzle,313,336);
        nozzle.setLocation(329,377);
        getWidth();
        nozzle.setLocation(331,321);
        gaspumpmachine.setLocation(537,352);
        nozzle.setLocation(326,320);
        gaspumpmachine.setLocation(537,353);
        nozzle.setLocation(576,425);
        nozzle.setLocation(429,425);
        nozzle.setLocation(327,377);
        creditcard.setLocation(868,260);
        creditcard.setLocation(869,259);
        removeObject(creditcard);
        ValidCard validcard = new ValidCard();
        addObject(validcard,905,107);
        validcard.setLocation(867,89);
        
        
        PremiumFuelButton premiumfuelbutton = new PremiumFuelButton();
        addObject(premiumfuelbutton,520,102);
        UnleadedFuelButton unleadedfuelbutton = new UnleadedFuelButton();
        addObject(unleadedfuelbutton,165,476);
        premiumfuelbutton.setLocation(890,424);
        unleadedfuelbutton.setLocation(443,458);
        premiumfuelbutton.setLocation(520,456);

        
        MenuButton menubutton = new MenuButton();
        addObject(menubutton,326,72);
        MenuButton menubutton2 = new MenuButton();
        addObject(menubutton2,318,187);
        MenuButton menubutton3 = new MenuButton();
        addObject(menubutton3,681,71);
        MenuButton menubutton4 = new MenuButton();
        addObject(menubutton4,685,195);
    }
}
