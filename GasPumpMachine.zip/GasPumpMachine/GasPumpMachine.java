import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class GasPumpMachine extends Actor
{
   
    Message m = new Message();
    CreditCard validCard;
    Actor haveCard;
    KeyPad key = new KeyPad(this);
    static Screen currentScreen;
    //Screen staticCurrentScreen;
    //Class validCard;
    
    public GasPumpMachine(){
        System.out.println("me adhi: ");
        //World world = getWorld();
        GreenfootImage image =getImage();
        image.scale(400,550); 
        //setMessage("Insert Card !",world);
    }
    
    public void setMessage( String msg, World world)
    {
     
       //int mouseX, mouseY ; 
       //MouseInfo mouse = Greenfoot.getMouseInfo();
       //System.out.println("setMessage: "+msg);
       //System.out.println("***"+mouse);
       //mouseX = mouse.getX();
       //mouseY = mouse.getY();
      
       if ( m.getWorld() != null )
       {
           world.removeObject( m) ;
           //System.out.println("world:" +world);
           
        }
        world.addObject( m, 481, 186 ) ;
       
        m.setText( msg );
    }
    
    public void act() 
    {
        
        World world = getWorld();
        //setMessage( "Insert Card",world ) ;
        Actor creditCard = getOneObjectAtOffset( +10, +10, CreditCard.class) ;
        if ( Greenfoot.mousePressed(this))
        {
            if ( haveCard == null ){
                setMessage( "Insert Card",world ) ;
            }
            else
                {
                //setMessage( "Crank Turned!",world);
                setMessage("Enter Zip",world) ;
                key.validateZip(world); // Call inspect to choose the picker
            }
        }
        
        if ( creditCard!= null )
        {
             //validCard = creditCard.getClass();
            if ( haveCard != null)
            {
                creditCard.move( +700 ) ;
            }
            else
            {
               
                //if ( validCard != null)
                //{
                    haveCard = creditCard ;
                    currentScreen = new EnterZipScreen(this);
                    currentScreen.display(world);
                    
                    //setMessage("Enter Zip",world) ;
                    //z.enterZip(world);
                    
                    Actor nozzle = getOneObjectAtOffset( -300, -30, Nozzle.class) ;
                    if ( nozzle != null)
                    {
                        setMessage("Gas Dispensing...",world);
                
                    }
                    
                /*}
                else
                {
                     setMessage("Insert Valid Card !",world) ;
                }*/
               // System.out.println("Coin"+haveCoin);
               // ((Coin)coin).inSlot() ;
            }
        }
        
    
        // Add your action code here.
    }
    
    public static Screen getCurrentScreen(){
        return currentScreen;
    }

}
