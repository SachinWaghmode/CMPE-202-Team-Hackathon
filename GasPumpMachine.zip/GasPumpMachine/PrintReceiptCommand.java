import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PrintReceiptCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PrintReceiptCommand implements Command{
  Screen receiver;
  
  public PrintReceiptCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  public void execute(World world){
    receiver.leftButtonClicked(world);
  }
}