import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HelpCommand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelpCommand implements Command{
  Screen receiver;
  
  public HelpCommand(Screen recScreen){
    this.receiver= recScreen;
  }
  
  
  public void execute(World world){
        System.out.println("Help Button execute : "+world); 
    receiver.leftButtonClicked(world);
   
  }
}