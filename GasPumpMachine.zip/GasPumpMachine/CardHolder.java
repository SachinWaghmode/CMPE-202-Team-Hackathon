import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CardHolder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CardHolder extends Actor
{
    /**
     * Act - do whatever the CardHolder wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public CardHolder(){
        GreenfootImage image =getImage();
        image.scale(200,250);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
