import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class KeyPad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class KeyPad extends Actor
{
    /**
     * Act - do whatever the KeyPad wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    World world = getWorld();
    MenuButton mn;
    
    //GasPumpMachince gs = new GasPumpMachine();
    GasPumpMachine gs;
    public KeyPad(GasPumpMachine gs){
         this.gs = gs;
         
    }
    public KeyPad(){
        GreenfootImage image =getImage();
        image.scale(200,250);
        
    }
    public void act() 
    {
      /*  if ( Greenfoot.mousePressed(this))
        {
            
                //setMessage( "Crank Turned!",world);
                setMessage("Enter Zip",world) ;
                z.enterZip(world); // Call inspect to choose the picker
           
        }
        // Add your action code here.
        */
    } 
    
    public String keyPress(World world){
        
        return "Enter";
    }
    
    public void validateZip(World world)
    {
       
        gs.currentScreen = new HelpScreen(gs);
        gs.currentScreen.display(world);
        
       
    }
    
}
