import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PrintReceiptScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PrintReceiptScreen extends Screen{
   
   public void leftButtonClicked(World world){
     System.out.println("This is your receipt");
   }
   
   public void rightButtonClicked(World world){
     System.out.println("this is No receipt message");
   }
   public void display(World world){
       //gs.setMessage("Insert Card...",world);
    }
}
