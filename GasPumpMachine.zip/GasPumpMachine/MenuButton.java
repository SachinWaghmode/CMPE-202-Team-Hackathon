import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Write a description of class MenuButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuButton extends Actor implements Invoker{
  Command theCommand;
  GasPumpMachine gs;
  
  public MenuButton(Command c){
    this.theCommand=c;
    
        GreenfootImage image =getImage();
        image.scale(40,30);
 
  }
  public MenuButton(GasPumpMachine gs){
      this.gs = gs;
    }
    public MenuButton(){
     
    }
  
  public void act(){
  if ( Greenfoot.mousePressed(this)){
      
     // gs= new GasPumpMachine();
     
        Command c = new HelpCommand(GasPumpMachine.getCurrentScreen());
            this.theCommand=c;
            this.press();
            
      List<MenuButton> lst = getWorld().getObjects(MenuButton.class);
     for(int i =0;i<lst.size();i++){
         //if(lst.get(i).isMousePressed()){
           
            //}
        }
    }
  
}
  
  public void press(){
    theCommand.execute(getWorld());
  }
}
