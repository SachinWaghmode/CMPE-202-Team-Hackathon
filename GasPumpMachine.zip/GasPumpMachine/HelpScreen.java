import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HelpScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelpScreen extends Screen{
   
    GasPumpMachine gs;
    //World world = getWorld();
    public HelpScreen(GasPumpMachine gs){
         this.gs = gs;
    }
   public void leftButtonClicked(World world){
     System.out.println("This is your Help message"+getWorld());
     gs.setMessage("Usage : ",world);
   }
   
   public void rightButtonClicked(World world){
     System.out.println("Display cancel message");
   }
   public void display(World world){
       gs.setMessage("Help       Cancel",world);
    }
}
